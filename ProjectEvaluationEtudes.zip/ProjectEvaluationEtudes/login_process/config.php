<?php
$databaseHost = 'localhost';
$databaseName = 'projetevaluation'; 
$databaseUsername ='root';
$databasePassword = '';

$connexion = mysqli_connect($databaseHost, $databaseUsername,$databasePassword,$databaseName);
 ?>