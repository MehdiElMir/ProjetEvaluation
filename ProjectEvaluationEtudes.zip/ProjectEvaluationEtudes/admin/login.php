<?php 

header("Location: pages/enquetes.php");