<?php include "../includes/layout.php" ?>

    <div class="main-content">
        filiers
    </div>

<?php include "../includes/footer.php" ?>