<?php include "../includes/layout.php" ?>

    <div class="main-content">
        <h3>Actions des Enseignants</h3>
        <table class="table-prof table">
            <thead>
                <tr>
                    <th class="p-2" scope="col">Nom d'enseignant</th>
                    <th>Module enseigner</th>
                    <th>action a proposer</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="p-2">enseignant 1</td>
                    <td>electro statique</td>
                    <td>
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Action
                        </button>   
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Action prof</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                    chi haja hna yktebha lprof
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="p-2">enseignant 1</td>
                    <td>electro statique</td>
                    <td>
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Action
                        </button>   
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Action prof</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                    chi haja hna yktebha lprof
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="p-2">enseignant 1</td>
                    <td>electro statique</td>
                    <td>
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Action
                        </button>   
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Action prof</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                    chi haja hna yktebha lprof
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="p-2">enseignant 1</td>
                    <td>electro statique</td>
                    <td>
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Action
                        </button>   
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Action prof</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                    chi haja hna yktebha lprof
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="p-2">enseignant 1</td>
                    <td>electro statique</td>
                    <td>
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Action
                        </button>   
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Action prof</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                    chi haja hna yktebha lprof
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

<?php include "../includes/footer.php" ?>