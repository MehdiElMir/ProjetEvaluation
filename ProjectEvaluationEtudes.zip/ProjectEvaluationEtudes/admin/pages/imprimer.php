<?php include "../includes/layout.php" ?>

    <div class="main-content">
        imprimer
    </div>

<?php include "../includes/footer.php" ?>